JOM JOM MESS — STARTER DEMO
===========================

গুরুত্বপূর্ণ:
এটি একটি প্রাথমিক PWA/UI ডেমো। এটি এখনো সম্পূর্ণ multi-user অ্যাপ নয়।
এই ডেমোতে তথ্য একই ফোনের browser storage-এ সেভ হয়। অন্য সদস্যের ফোনে
একই তথ্য দেখানোর জন্য Firebase Authentication + Firestore + নিরাপদ
Security Rules সংযোগ করতে হবে। ডেমো Role dropdown নিরাপদ Admin login নয়;
এটি শুধু UI পরীক্ষা করার জন্য। বাস্তব ব্যবহারে এই ডেমোকে সরাসরি ব্যবহার
করবেন না এবং বাস্তব টাকা/ব্যক্তিগত তথ্য রাখবেন না।

ফাইল:
- index.html: অ্যাপের UI ও ডেমো ফিচার
- manifest.json: PWA metadata
- sw.js: basic offline cache

Android ফোনে বিনামূল্যে পরীক্ষা:
1. ZIP extract করার অ্যাপ দিয়ে এই ZIP ফাইল extract করুন।
2. index.html ফাইলটি Chrome-এ খুললে UI পরীক্ষা করা যেতে পারে; কিছু PWA
   ফিচার file:// থেকে কাজ নাও করতে পারে।
3. PWA ইনস্টল করার জন্য HTTPS hosting দরকার। ফ্রি উপায় হিসেবে GitHub Pages
   ব্যবহার করতে পারেন:
   - github.com এ sign in / account তৈরি করুন।
   - New repository তৈরি করুন, যেমন jom-jom-mess.
   - এই ফোল্ডারের index.html, manifest.json, sw.js আপলোড করুন।
   - Repository Settings > Pages এ গিয়ে Deploy from a branch নির্বাচন করুন,
     branch main এবং folder /(root) নির্বাচন করে Save করুন।
   - প্রকাশিত https://...github.io/... লিংক Android Chrome-এ খুলুন।
   - Chrome-এর ⋮ মেনু > Add to Home screen / Install app নির্বাচন করুন।
   GitHub-এর menu wording সময়ের সঙ্গে বদলাতে পারে।
4. এই ইনস্টল পদ্ধতি একটি PWA/হোম-স্ক্রিন অ্যাপ; এটি নিজে থেকে signed APK নয়।
   আলাদা APK দরকার হলে Android ফোন থেকে কোনো online build workflow বা
   Android IDE ব্যবহার করতে হবে। সব ফ্রি build service-এর usage limit থাকে।

বাস্তব ব্যবহারের আগে প্রয়োজন:
- Firebase Authentication দিয়ে প্রত্যেক সদস্যের নিজস্ব account
- Firestore database
- server-enforced role checks এবং Security Rules
- সর্বোচ্চ ২ Admin সীমা enforce করার নিরাপদ transaction/backend logic
- meal day reset/timezone (Asia/Dhaka), deadline checks server-side
- monthly handover, audit log, backups, member-specific permissions
- হিসাবের নিয়ম ও rounding পরীক্ষা

নিরাপত্তা:
কখনোই Admin password বা Firebase service-account private key HTML/JavaScript
ফাইলে রাখবেন না। Firebase config public হওয়া স্বাভাবিক, কিন্তু database
Security Rules সঠিক না হলে তথ্য অনিরাপদ হতে পারে।
